<h1>Task has been created</h1><br>
<h3>New Filled info:</h3>
<p><b>Task Id : </b>{{$data['id']}}</p><br>
<p><b>Title : </b>{{$data['title']}}</p><br>
<p><b>Updated date :</b> {{$data['updated_at']}}</p><br>