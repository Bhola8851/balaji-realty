<h1>User has edited </h1><br>
<h3>New Filled info:</h3>
<p><b>User Id :</b> {{$data['id']}}</p><br>
<p><b>Name :</b> {{$data['name']}}</p><br>
<p><b>Email :</b> {{$data['email']}}</p><br>
<p><b>phone :</b> {{$data['phone']}}</p><br>
<p><b>Type :</b> {{$data['type']}}</p><br>
<p><b>Updated date :</b> {{$data['updated_at']}}</p><br>