<h1><b> This is user </b>{{$data['name']}}</h1><br>
<h3><b>email : </b>{{$data['email']}}</h3><br>
<h3><b>phone: </b>{{$data['phone']}}</h3><br>
<h3><b>Query: </b>{{$data['queryi']}}</h3><br>

