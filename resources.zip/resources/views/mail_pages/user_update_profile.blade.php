<h1>User Profile has updated </h1><br>

<h1>New Data</h1>

<p class="h3"><b>Id :</b> {{$data['id']}}</p><br>
<p class="h3"><b>Name :</b> {{$data['name']}}</p><br>
<p class="h3"><b>Email :</b> {{$data['email']}}</p><br>
<p><b>Updated date :</b> {{$data['updated_at']}}</p><br>