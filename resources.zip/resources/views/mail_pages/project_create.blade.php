<h1>User has been created</h1><br>
<h3>New Filled info:</h3>
<p><b>Project Id :</b> {{$data['id']}}</p><br>
<p><b>Project Title : </b>{{$data['title']}}</p><br>
<p><b>Deal Type :</b> {{$data['deal_type']}}</p><br>
<p><b>Created date :</b> {{$data['created_at']}}</p><br>