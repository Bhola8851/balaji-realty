<h1>Thank You For Contacting Us</h1><br>
<h3>Your Filled info:</h3>
<p><b>Name : </b>{{$data['name']}}</p><br>
<p><b>email :</b> {{$data['email']}}</p><br>
<p><b>phone :</b> {{$data['phone']}}</p><br>
<p><b>Query :</b> {{$data['queryi']}}</p>
