


    <div class="col-md-12" style="border-top: 1px solid #b2b2b2;">
    <footer style="background:#222;">
        <div class="container" >
            <div class="row">
                <div class="col-md-4">
                    <h3>+91-9876245612</h3>
                    <p>Phone: +91-8725637524</p>
                    <p>Email: balajiwebsite@gmail.com</p>
                </div>
                <div class="col-md-8">
                    <h3>Our Mission</h3>
                    <p>“HAND IN HAND TOGETHER WITH OUR DISTRIBUTORS TO ACHIEVE A MUTUAL SUCCESS IN THE DIRECT SELLING INDUSTRY”</p>
                </div>
            </div>
            <div class="bottom-footer">
                <div class="row">
                    <div class="col-md-5">
                        <p>
                            <small>

                                &copy; Copyright &copy;
                                All rights reserved |<br />
                                This website is made with <i class="glyphicon glyphicon-flag" aria-hidden="true"></i> by <a id="copyright" href="https://www.facebook.com/bholasinghbunty" target="_blank" style="color:#ffd800;">Bhola Singh | Shubham Yadav</a>

                            </small>
                        </p>
                    </div>
                    <div class="col-md-7">
                        
                        <ul class="footer-nav">
                            <li><a href="/">Home</a></li>
                            <li><a href="/project">Projects</a></li>
                            <li><a href="/about_us">About Us</a></li>
                            <li><a href="/contacts">Contacts</a></li>
                            <li><a href="{{ route('login') }}">Login</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    </div>
