/*$(document).ready(function(){
    
    $('#banner').click(function(){
        if($('#banner').val() == 'Ban User'){
            $ban = $('#banner').val('Unban User');
        
        }
        else if($('#banner').val() == 'Unban User'){
            $ban = $('#banner').val('Ban User');
            
        }
        
    });
    $('#banner').val($ban);
});*/